#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include "fonction.h"

void ajout(char *agents, agent a)
{
    FILE *f = fopen(agents, "a+");
    if (f == NULL)
    {
        printf("Error \n");
        return;
    }

    strcpy(a.park, "NULL");

    fprintf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d\n", 
            a.id_agent, a.nom_agent, a.prenom_agent, a.sexe_agent, 
            a.sal_agent, a.type_contact, a.contact, a.moyen_agent, 
            a.park, a.fonction_agent, a.date_agent.j, a.date_agent.m, a.date_agent.a);

    fclose(f);
}

int verify(char *agents, char *id)
{
    int t = 0;
    agent a;

    FILE *f = fopen(agents, "r");
    if (f == NULL)
    {
        printf("Error");
        return 0;
    }

    while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
    {
        if (strcmp(id, a.id_agent) == 0)
        {
            t = 1;
            break;
        }
    }

    fclose(f);
    return t;
}

void sexe (char msg[],int choix)
{
if(choix==1)
{
strcpy(msg,"male");
}
else
{
strcpy(msg,"female");
}
}

void moyen(char msg[], int choix[]) {
      

    if (choix[0] == 1) {
        strcpy(msg, "voiture");
        
    }
    if (choix[1] == 1) {
        
            strcat(msg, "_moto"); 
        
    }
    if (choix[2] == 1) {
        
            strcat(msg, "_aucun"); 
       
        
    }
}


void supp_agent(char *agents,char *temp_agents,char c[])
		{

		
			FILE *f = fopen(agents, "r");  
    			if (f == NULL) {
        		printf("erreur \n");
        		return;
    			}
			FILE *f1 = fopen(temp_agents, "w");
			if (f1 == NULL) {
        		printf("erreur \n");
        		return;
    			}
			agent a;
			
		while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
			{
       
			if(strcmp(c,a.id_agent)!=0)	
							{
				fprintf(f1, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d\n", 
            a.id_agent, a.nom_agent, a.prenom_agent, a.sexe_agent, 
            a.sal_agent, a.type_contact, a.contact, a.moyen_agent, 
            a.park, a.fonction_agent, a.date_agent.j, a.date_agent.m, a.date_agent.a);
    							}

				}
			
			
			fclose(f);
			fclose(f1);
			
			remove(agents);
			rename(temp_agents,agents);
			
			
			
			
		

			
		
			}


void mod_agent(char *agents, char *temp_agents, char c[], agent *a) {
    int x;

    FILE *f = fopen(agents, "r+");  
    if (f == NULL) {
        printf("Error\n");
        return;
    }
    FILE *f1 = fopen(temp_agents, "w+");
    if (f1 == NULL) {
        printf("Error\n");
        fclose(f);
        return;
    }

    agent temp_agent;
    while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  temp_agent.id_agent, 
                  temp_agent.nom_agent, 
                  temp_agent.prenom_agent, 
                  temp_agent.sexe_agent, 
                  temp_agent.sal_agent, 
                  temp_agent.type_contact, 
                  temp_agent.contact, 
                  temp_agent.moyen_agent, 
                  temp_agent.park, 
                  temp_agent.fonction_agent, 
                  &temp_agent.date_agent.j, 
                  &temp_agent.date_agent.m, 
                  &temp_agent.date_agent.a) != EOF) 
    {
        if (strcmp(c, temp_agent.id_agent) == 0) {
            
            strcpy(temp_agent.nom_agent, a->nom_agent);
            strcpy(temp_agent.prenom_agent, a->prenom_agent);
            strcpy(temp_agent.contact, a->contact);
            strcpy(temp_agent.fonction_agent, a->fonction_agent);
            strcpy(temp_agent.sal_agent, a->sal_agent);
            strcpy(temp_agent.sexe_agent, a->sexe_agent);
            strcpy(temp_agent.moyen_agent, a->moyen_agent);
            strcpy(temp_agent.type_contact, a->type_contact);
            temp_agent.date_agent.j = a->date_agent.j;
            temp_agent.date_agent.m = a->date_agent.m;
            temp_agent.date_agent.a = a->date_agent.a;
        }
        
       
        fprintf(f1, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d\n", 
                temp_agent.id_agent, temp_agent.nom_agent, temp_agent.prenom_agent, 
                temp_agent.sexe_agent, temp_agent.sal_agent, temp_agent.type_contact, 
                temp_agent.contact, temp_agent.moyen_agent, temp_agent.park, 
                temp_agent.fonction_agent, temp_agent.date_agent.j, 
                temp_agent.date_agent.m, temp_agent.date_agent.a);
    }

    fclose(f);
    fclose(f1);
    
    
    remove(agents);
    rename(temp_agents, agents);


}
int verifier_service(char *services, char id[]) {
    service s1;
    int x = 0;
    FILE *f = fopen(services, "r+");

    if (f == NULL) {
        printf("Erreur  %s\n", services);
        return x; 
    }

    while (fscanf(f, "%s %s %s %s %s %s", s1.id_service, s1.tarif, s1.type_service, s1.autres_services, s1.dispo, s1.duree_estime) != EOF) {
        if (strcmp(id, s1.id_service) == 0) {
            x = 1;
            break;
        }
    }

    fclose(f);
    return x; 
}

void ajouter_service(char *services, service s1) {
    FILE *f = fopen(services, "a");

    if (f == NULL) {
        printf("Erreur  %s\n", services);
        return; 
    }

    fprintf(f, "%s %s %s %s %s %s\n", s1.id_service, s1.tarif, s1.type_service, s1.autres_services, s1.dispo, s1.duree_estime);
    fclose(f);
}

void duree (char msg[],int choix)
{
if(choix==1)
{
strcpy(msg,"30Min");
}
if(choix==2)
{
strcpy(msg,"1H");
}
if(choix==3)
{
strcpy(msg,"2H");
}
}

void dispo(char msg[], int choix[]) 
{
      

    if (choix[0] == 1) {
        strcpy(msg, "24_H");
        
    }
    if (choix[1] == 1) {
        
            strcat(msg, "_matin"); 
        
    }
    if (choix[2] == 1) {
        
            strcat(msg, "_nuit"); 
       
        
    }
}


void mod_service(char *services, char *temp_services, char c[], service *s1) {
    FILE *f = fopen(services, "r+");
    if (f == NULL) {
        printf("Erreur\n");
        return;
    }

    FILE *f1 = fopen(temp_services, "w+");
    if (f1 == NULL) {
        printf("Erreur\n");
        fclose(f);
        return;
    }

    service temp_service;
    while (fscanf(f, "%s %s %s %s %s %s", 
                  temp_service.id_service, 
                  temp_service.tarif, 
                  temp_service.type_service, 
                  temp_service.autres_services, 
                  temp_service.dispo, 
                  temp_service.duree_estime) != EOF) 
    {
        if (strcmp(c, temp_service.id_service) == 0) {
            strcpy(temp_service.tarif, s1->tarif);
            strcpy(temp_service.type_service, s1->type_service);
            strcpy(temp_service.autres_services, s1->autres_services);
            strcpy(temp_service.dispo, s1->dispo);
            strcpy(temp_service.duree_estime, s1->duree_estime);
        }

        fprintf(f1, "%s %s %s %s %s %s\n", 
                temp_service.id_service, temp_service.tarif, temp_service.type_service, 
                temp_service.autres_services, temp_service.dispo, temp_service.duree_estime);
    }

    fclose(f);
    fclose(f1);

    remove(services);
    rename(temp_services, services);
}

void supp_service(char *services, char *temp_services, char c[]) {
    FILE *f = fopen(services, "r");  
    if (f == NULL) {
        printf("erreur\n");
        return;
    }
    
    FILE *f1 = fopen(temp_services, "w");
    if (f1 == NULL) {
        printf("erreur\n");
        fclose(f);
        return;
    }

    service s;

    while (fscanf(f, "%s %s %s %s %s %s", 
                  s.id_service, 
                  s.tarif, 
                  s.type_service, 
                  s.autres_services, 
                  s.dispo, 
                  s.duree_estime) != EOF) {
        
        if (strcmp(c, s.id_service) != 0) {
            fprintf(f1, "%s %s %s %s %s %s\n", 
                    s.id_service, s.tarif, s.type_service, 
                    s.autres_services, s.dispo, s.duree_estime);
        }
    }

    fclose(f);
    fclose(f1);

    remove(services);
    rename(temp_services, services);
}


		
		
