#ifndef FONCTION_H
#define FONCTION_H

typedef struct
{
int j;
int m;
int a;
}date;


typedef struct
{

char id_agent[100];
char nom_agent[100];
char prenom_agent[100];
char sexe_agent[100];
char sal_agent[100];
char type_contact[100];
char contact[100];
char moyen_agent[100];
char park[100];
char fonction_agent[100];
date date_agent;
} agent ;



typedef struct 
{
  char id_service[100];
  char tarif[100];
  char type_service[100];
  char autres_services[100];
  char dispo[100];
  char duree_estime[100];
}service;

void ajout(char *agents, agent a);
int verify(char *agents, char *id);
void sexe (char msg[],int choix);
void moyen (char msg[],int choix[]);
void supp_agent(char *agents,char *temp_agents,char c[]);
void mod_agent(char *agents, char *temp_agents, char c[], agent *a);
int verifier_service(char *services,char *id);
void ajouter_service(char *services,service s1);
void duree (char msg[],int choix);
void dispo(char msg[], int choix[]) ;
void mod_service(char *services, char *temp_services, char c[], service *s1);
void supp_service(char *services, char *temp_services, char c[]);



#endif
